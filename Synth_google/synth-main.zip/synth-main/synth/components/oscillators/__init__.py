from .oscillators import SineOscillator
from .oscillators import SquareOscillator
from .oscillators import SawtoothOscillator
from .oscillators import TriangleOscillator
from .modulated_oscillator import ModulatedOscillator