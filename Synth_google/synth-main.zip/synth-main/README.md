# synth
![Making A Synth Banner](images/banner.png)
An attempt at making a synth using Python

---

The process has been documented through a series of posts.

1. **Oscillators** : [Link](https://18alan.medium.com/making-a-synth-with-python-oscillators-2cb8e68e9c3b)
2. **Modulators** : [Link](https://18alan.medium.com/build-your-own-python-synthesizer-part-2-66396f6dad81)
3. **Controllers** : [Link](https://18alan.medium.com/build-your-own-python-synthesizer-part-3-162796b7d351)
